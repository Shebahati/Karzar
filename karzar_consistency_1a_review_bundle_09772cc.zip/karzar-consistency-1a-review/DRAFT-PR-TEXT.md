## Consistency 1A — private account state (F01/F02)

Isolates saved addresses and private React Query caches behind a verified customer session (generation-scoped). Legacy unowned address persist is discarded on migrate.

**Out of scope:** F03 cart ownership, F08 server logout proof (failed HTTP logout leaves server session unconfirmed), F06 profile PATCH policy, payment/shipping/inventory.

**F08 wording:** Client clears private state on logout attempt; a failed or lost logout response does not prove HttpOnly session revocation on the server.
