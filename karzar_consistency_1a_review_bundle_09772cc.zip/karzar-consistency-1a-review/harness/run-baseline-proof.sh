#!/usr/bin/env bash
set -euo pipefail
ART=/opt/cursor/artifacts/karzar-consistency-1a
BASE=83949bcfcc20d976a856a19f3d0a543a606bd817
PATCH_ROOT=/workspace
WT=/tmp/karzar-wt-83949bc
BASE_SF="$WT/frontend/Storefront"
LOG="/tmp/karzar-consistency-1a-baseline-proof.log"

{
  echo "Baseline immutable base: $BASE"
  echo "Patch HEAD: $(git -C "$PATCH_ROOT" rev-parse HEAD)"
  echo "=== Ensure worktree @ $BASE ==="
  if [[ ! -e "$WT/.git" ]]; then
    git -C "$PATCH_ROOT" worktree add -f "$WT" "$BASE"
  fi
  ln -sfn "$PATCH_ROOT/frontend/Storefront/node_modules" "$BASE_SF/node_modules"

  echo "=== BASELINE vitest (expect FAIL) ==="
  cp "$ART/harness/baseline-main-regression.test.ts" "$BASE_SF/src/store/__tests__/baseline-regression.test.ts"
  set +e
  ( cd "$BASE_SF" && ./node_modules/.bin/vitest run src/store/__tests__/baseline-regression.test.ts --pool=threads --maxWorkers=1 )
  BASE_EXIT=$?
  set -e
  rm -f "$BASE_SF/src/store/__tests__/baseline-regression.test.ts"
  echo "BASE_EXIT=$BASE_EXIT"

  echo "=== PATCH vitest (expect PASS) ==="
  cp "$ART/harness/baseline-regression.test.ts" "$PATCH_ROOT/frontend/Storefront/src/store/__tests__/baseline-regression.test.ts"
  set +e
  ( cd "$PATCH_ROOT/frontend/Storefront" && ./node_modules/.bin/vitest run src/store/__tests__/baseline-regression.test.ts --pool=threads --maxWorkers=1 )
  PATCH_EXIT=$?
  set -e
  rm -f "$PATCH_ROOT/frontend/Storefront/src/store/__tests__/baseline-regression.test.ts"
  echo "PATCH_EXIT=$PATCH_EXIT"

  if [[ "$BASE_EXIT" -ne 0 && "$PATCH_EXIT" -eq 0 ]]; then
    echo "BASELINE_PROOF=OK"
  else
    echo "BASELINE_PROOF=UNEXPECTED base_exit=$BASE_EXIT patch_exit=$PATCH_EXIT"
  fi
} 2>&1 | tee "$LOG"

cp "$LOG" "$ART/baseline-proof.log"
grep -q BASELINE_PROOF=OK "$LOG"
