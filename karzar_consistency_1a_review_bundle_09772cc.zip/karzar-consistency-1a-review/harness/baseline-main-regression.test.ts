/**
 * Secure assertions run against extracted main@83949bc Storefront (expected FAIL).
 */
import { act, createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useAddressStore } from "@/store/address-store";
import { useMyOrders } from "@/features/orders/queries";
import { orderService } from "@/services/orders";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT =
  true;

vi.mock("@/lib/api-client", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/api-client")>();
  return { ...actual, isLoggedIn: () => true };
});

function renderHook<T>(hook: () => T, client: QueryClient) {
  const container = document.createElement("div");
  const root: Root = createRoot(container);
  const out: { current: T | undefined } = { current: undefined };
  function Host() {
    out.current = hook();
    return null;
  }
  act(() => {
    root.render(
      createElement(
        QueryClientProvider,
        { client },
        createElement(Host),
      ),
    );
  });
  return { unmount: () => act(() => root.unmount()) };
}

describe("F01 secure address boundary (main API)", () => {
  beforeEach(() => {
    localStorage.clear();
    useAddressStore.setState({ addresses: [] });
  });

  it("does not expose saved addresses without verified owner", () => {
    useAddressStore.setState({
      addresses: [
        {
          id: "legacy",
          label: "home",
          full_name: "Leaked A",
          phone: "09120000001",
          province: "p",
          city: "c",
          postal_code: "1234567890",
          address_line: "line",
          is_default: true,
        },
      ],
    });
    expect(useAddressStore.getState().getDefault()).toBeUndefined();
  });
});

describe("F02 secure private orders boundary (main API)", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it("does not call listMine without verified owner", async () => {
    const listSpy = vi.spyOn(orderService, "listMine").mockResolvedValue({
      data: [],
      meta: { total_count: 0, skip: 0, limit: 5, has_next: false, has_prev: false },
    });
    const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    renderHook(() => useMyOrders({ limit: 5 }), client);
    await new Promise((r) => setTimeout(r, 50));
    expect(listSpy).not.toHaveBeenCalled();
  });
});
