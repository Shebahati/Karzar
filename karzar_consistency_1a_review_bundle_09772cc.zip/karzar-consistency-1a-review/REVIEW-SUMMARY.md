# Consistency 1A review bundle

- **Immutable diff base:** `83949bcfcc20d976a856a19f3d0a543a606bd817`
- **Implementation start:** `ac9f444dbf2da6effdeb792e565b4e6d8aa07d61`
- **Reviewed HEAD:** `09772ccee67ddd33c323a8c789224e2095b18a52`
- **origin/main at fetch:** `c40bccb9bca280d837a03d8a631bf9e4fb153fed` (not the diff base)
- **Branch:** fix/consistency-1a-private-account-state
- **Worktree:** clean tracked tree; bundle built from committed HEAD

## C1–C4

- **C1/T02:** `private-session-boundary.test.tsx` — seeded A LS + v2 addresses; Providers + SessionProbe; no A profile/address/orders while `/me` pending; `listMine` not called; after B resolve only B data; bounded `/me` calls.
- **C2/T09:** `address-session.test.tsx` + `account-addresses-session.test.tsx` — mounted DetailsStep/AccountAddressesView; owner switch clears fields/selection; save/submit cannot write A into B bucket; same-owner preserves draft.
- **C3/T04:** `address-store.test.ts` — legacy Zustand envelope (version 0 flat `state.addresses`), invalid JSON/shape, getItem/setItem failures, A→B→A bucket preservation.
- **C4:** `auth-session.test.tsx` + `private-orders-session.test.tsx` — USE_MOCK=false; real services/hooks; intercepted Axios; A→logout→B, delayed A orders response.

## Baseline F01/F02

Command: `bash harness/run-baseline-proof.sh` (worktree @ base + harness tests).

- **BASE_FAIL:** F01 `getDefault` returns leaked address on main@83949bc; F02 `listMine` invoked when logged-in mock without verified owner (after act import fix).
- **PATCH_PASS:** same harness against patch HEAD — `BASELINE_PROOF=OK` in validation/baseline-proof.log.

## Gates (HEAD 09772ccee67ddd33c323a8c789224e2095b18a52)

See validation/*.log — lint 0 errors / 59 warnings; typecheck pass; 321 tests pass; build pass; aods PASS (openapi SKIP — no FastAPI).

## Migration

Legacy flat `karzar.addresses` without `byOwner` is discarded (non-recoverable unowned snapshot).
