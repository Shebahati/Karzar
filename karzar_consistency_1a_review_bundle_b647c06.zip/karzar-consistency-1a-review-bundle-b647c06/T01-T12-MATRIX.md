# T01–T12 evidence matrix (Storefront unit / intercepted transport)

| ID | Status | Mode | Primary test(s) |
|----|--------|------|-----------------|
| T01 | PASS | state + live transport | `address-store.test.ts` owner switch; `private-orders-session.test.tsx` keys; `auth-session.test.tsx` C4/T01 |
| T02 | PASS | mounted Providers + intercepted `/me` | `private-session-boundary.test.tsx` C1/T02 |
| T03 | PASS | Zustand store | `address-store.test.ts` returning owner A |
| T04 | PASS | real persist paths | `address-store.test.ts` C3/T04 legacy envelope v0, invalid JSON/shape, setItem failure |
| T05 | PASS | module | `customer-session.test.ts` generation on invalidate |
| T06 | PASS | intercepted transport | `auth-session.test.tsx` stale /me, A→B late profile, **A→logout→late-A** (hook + `authService`), mergeLocalProfile, fence unit |
| T07 | PASS | real logout service + delayed transport | `auth-session.test.tsx` T07 pair |
| T08 | PASS | hooks | `private-orders-session.test.tsx` mount + manual refetch; `customer-session.test.ts`; `address-store.test.ts` getters |
| T09 | PASS | mounted consumers | `address-session.test.tsx`; `account-addresses-session.test.tsx` |
| T10 | PASS | service getters | `private-address-consumers.test.ts` |
| T11 | PASS | mounted Providers + synthetic storage (receiver-only) | `private-session-boundary.test.tsx` SIGNAL/STOREFRONT/ADDRESS no-rebroadcast + reverify; `customer-session.test.ts` `notifyExternalSessionHint` silent |
| T12 | PASS | mounted paths | `private-session-boundary.test.tsx` duplicate auth-change; `address-session.test.tsx` same-owner preserve |

Browser OTP / two-tab: **NOT RUN** (no real two-context browser harness executed; synthetic StorageEvent only).

Backend integration: **NOT RUN** (transport intercepted; USE_MOCK=false seam only).
