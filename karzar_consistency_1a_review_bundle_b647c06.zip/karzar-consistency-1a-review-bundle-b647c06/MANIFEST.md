# MANIFEST

- Immutable base: `83949bcfcc20d976a856a19f3d0a543a606bd817`
- HEAD: `b647c06118d067a33290c7064f98bb528daac1b7`
- origin/main: `9fc607ab90170375069c0d5b11ec33f4f64ae9dd`
- Built: 2026-10-06T11:03:22Z

| Path | SHA-256 |
|------|---------|
| `changed-paths.txt` | `53ccc4e298525edbd5c6d02f59e4bff75b2c384c776530528c01b4eb212edeb9` |
| `diff/cumulative.patch` | `abb1a761cb3762269ab5f99abdf57084d3ebe6455bc04e98eaf7591620c66dc2` |
| `diff/format-patches/0001-fix-storefront-isolate-private-addresses-and-account.patch` | `12a9540cf309d0ec64141ecc5f7effb9745a74c7593293da21e1e6c6894d20b9` |
| `diff/format-patches/0002-test-storefront-close-consistency-1A-acceptance-gaps.patch` | `eff971a9a4d8df4302e60a47c7a759276fbd44d442503f438f33db66b2c01f95` |
| `diff/format-patches/0003-test-storefront-fix-catalog-cache-probe-lint-and-eff.patch` | `15b9d8d941f767a413abf69f1154e2c7ce38455c914d32824f38c8e6fc00f040` |
| `diff/format-patches/0004-test-storefront-stabilize-T06-late-profile-mutation-.patch` | `3ccf226679e48c124afbe587dc325e4f9ce2d89a50203fe4d6c4e1176fba3437` |
| `diff/format-patches/0005-chore-review-add-consistency-1A-review-bundle-09772c.patch` | `d3c5cab8cd7ed2c2f4a81d6332f722bfc6d77037cdeabf8bfc0f8d46bca19899` |
| `diff/format-patches/0006-fix-storefront-close-Consistency-1A-profile-fence-an.patch` | `ec3085ea687433094d452ea22eb0796deb48f1bf6d9d58e569ef5df8df3842f4` |
| `DRAFT-PR-TEXT.md` | `26ac0ec3e0e95645516b9065067085b8535fe7ca8172a2e738ab05d5a5c9c9fe` |
| `files/aods/registry/document-registry.yaml` | `1b0e9066b6ca70d6966fa144df5f9cb2c0be9458a3bf0b51f6e08888b0950f42` |
| `files/docs/development/consistency-1a-private-account-state.md` | `4d3475c5e79a92390539b59b7db3a0c581aaa7567bb66356059a1ad8bf1dd2d6` |
| `files/frontend/Storefront/src/app/providers.tsx` | `2ea4d4fcae5511b6d635e12b1c497d24321c0a945d68b237d07799b0b292ac02` |
| `files/frontend/Storefront/src/app/__tests__/private-session-boundary.test.tsx` | `c81aa25304cf1012e02ed943e8d6501a83ee03c2c033efaf861b2526ac77be35` |
| `files/frontend/Storefront/src/components/account/account-addresses-view.tsx` | `f2d344dd345b9d7606a8fdf7c9c17e5384caa7bdd840eb3d2667f75a640748ad` |
| `files/frontend/Storefront/src/components/account/__tests__/account-addresses-session.test.tsx` | `61e2e5c72f38422f16850f21e326ddc0cff934832c195f3770d722b740ed3e9a` |
| `files/frontend/Storefront/src/components/auth/login-view.tsx` | `4c567ba9e6940452a7663939094e3cdd36696512c90a6cb7d34c469e13f21fb0` |
| `files/frontend/Storefront/src/components/checkout/details-step.tsx` | `0fa4ac739bd9729079bbffb2ec81208c934fa3bf6884dc9890d27e44f41a9876` |
| `files/frontend/Storefront/src/components/checkout/__tests__/address-session.test.tsx` | `462c3bb8e7baf5e49e2ab519b13cf90130b46a0496b2a1e288d3d0058bbabc37` |
| `files/frontend/Storefront/src/features/auth/queries.ts` | `6b614da16dc6985db7d4ff68a51446077ca994b5d45d1effd384ffc150098e87` |
| `files/frontend/Storefront/src/features/auth/__tests__/auth-session.test.tsx` | `e0c8a9cbcc39709136b33161445b2d34b543b05a09f47df4dba5f7c1d4f28411` |
| `files/frontend/Storefront/src/features/orders/queries.ts` | `73f1b02f791e89a2903ec97d8a485a8707de54e01a55294b9e601caf5f110450` |
| `files/frontend/Storefront/src/features/orders/__tests__/private-orders-session.test.tsx` | `379a12612e7a06a1dca9ed32f359832effc52f27098e2a954b0577ea3a7e1154` |
| `files/frontend/Storefront/src/lib/api-client.ts` | `19540e10eb4673cad14e69870c282a556688f075b5efa8d2a78ed8c18ae343e4` |
| `files/frontend/Storefront/src/lib/customer-session.ts` | `015c71faaa37ea2dd99c8935c8c50b18a86fc4c38de2b8ba2e54cd5c2c40bcf6` |
| `files/frontend/Storefront/src/lib/__tests__/customer-session.test.ts` | `4616fa3bdbd3b0dd0b62ce5467eb4e6b91aff36c85c6f90e6c41bb9eee1c646e` |
| `files/frontend/Storefront/src/services/auth.ts` | `bcdb9dee575480da4f50b600dc6d32130bfa9d025e6559fb0000e2f2dec309b8` |
| `files/frontend/Storefront/src/services/order-invoice.ts` | `fa79cb53d9079d5d3859920bd10a314c463034e941ef291d97be93f8c69e1d26` |
| `files/frontend/Storefront/src/services/orders.ts` | `fe99b081c5bfe6d36c0683f29d8b696f5a0cc9362fe844988b04a23d30efcb40` |
| `files/frontend/Storefront/src/services/__tests__/private-address-consumers.test.ts` | `4aad53f6dfe36d0826eea7730cea6888a86b0afcc40d980c0ccf60ae4e551efd` |
| `files/frontend/Storefront/src/store/address-store.ts` | `48664417eda37e7c86a4270ade79cf0ce8c634f78d4d3f842382e84ea536ac15` |
| `files/frontend/Storefront/src/store/__tests__/address-store.test.ts` | `a24bb3fff98b886fd7b9d66959fda8431ca312c1242651100b64203b1d957bf6` |
| `files/karzar_consistency_1a_review_bundle_09772cc.zip` | `d846604dc0661fa7c50fad4d88d2b54d8cd03cff75b93c2a94070deac47d4705` |
| `harness/baseline-main-regression.test.ts` | `0bc769540d32e5f48bc972bce1f38a903cce40fef312052b863e29da48eec643` |
| `harness/baseline-regression.test.ts` | `a2b4b9cad13a38574ee07f9420b3d483c8e95af852acbff56a6eeae0814c0af2` |
| `harness/run-baseline-proof.sh` | `c76343990e0926ad2def6b18f8418dcddd269e0a42dbf35d484212af603c753b` |
| `IMPLEMENTATION-NOTE.md` | `4d3475c5e79a92390539b59b7db3a0c581aaa7567bb66356059a1ad8bf1dd2d6` |
| `REVIEW-SUMMARY.md` | `50371e4263caa0cc3063615e06c23510a620763f1377c8a715d79f700ecf94d7` |
| `T01-T12-MATRIX.md` | `87f07e2f9d2ca5880519de1eccd702c9905c12855cf4151a163d9bd81cf1660f` |
| `validation/baseline-proof.log` | `4a3c8cd195c17b7781d00cc3783749b0c90c64b0ea6928cf2f350ed04303c4fc` |
| `validation/karzar-aods.log` | `964e8497970c7a0868b8c179f2235509ad37b90c83f10418da4f402214e21bbe` |
| `validation/karzar-build.log` | `2835c6550d34c91321bbba842f03aac2b8daadb04c609ce3cfcb26f70fc96531` |
| `validation/karzar-lint.log` | `614ce9c52457e2b8d5e2e578816f2069520058e99e1e9c7fbd821329a116c661` |
| `validation/karzar-test.log` | `09748d83758761b578f9095c2e83387e02cec59c5e3474881f902a246fd58f4b` |
| `validation/karzar-typecheck.log` | `36bfe70c75672a2d90fd19537768952f96553301562e1492fdf37ea63434a04d` |
