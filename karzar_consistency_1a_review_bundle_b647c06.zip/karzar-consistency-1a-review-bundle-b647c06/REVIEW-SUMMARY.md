# Consistency 1A review bundle (blocker closeout)

- **Immutable diff base:** `83949bcfcc20d976a856a19f3d0a543a606bd817`
- **Implementation start:** `ac9f444dbf2da6effdeb792e565b4e6d8aa07d61`
- **Previous reviewed HEAD:** `09772ccee67ddd33c323a8c789224e2095b18a52`
- **New HEAD:** `b647c06118d067a33290c7064f98bb528daac1b7`
- **origin/main at fetch:** `9fc607ab90170375069c0d5b11ec33f4f64ae9dd` (not the diff base; branch was not rebased)
- **Branch:** fix/consistency-1a-private-account-state
- **Worktree:** clean tracked tree after closeout commit; bundle built from committed HEAD

## Review blocker closeout

### Blocker A — late profile mutation after logout
- Root cause: `authService.updateProfile` wrote `STOREFRONT_CUSTOMER_KEY` after await without an owner/generation fence; hook `onSuccess` treated `verifiedCustomerId=null` as permission to `establishVerifiedCustomer`.
- Fix: `captureVerifiedCustomerSessionFence` / `isCustomerSessionFenceCurrent` checked immediately before persist and before cache/establish side effects.
- Tests: T06 A→logout→late-A (hook + service); existing A→B late-mutation retained.

### Blocker B — cross-tab signal rebroadcast
- Root cause: `notifyExternalSessionHint` → `invalidateCustomerSession` broadcast `CUSTOMER_SESSION_SIGNAL_KEY` again; receivers bounced indefinitely.
- Fix: `invalidateCustomerSession(..., { broadcast })`; external-hint path is receiver-only; soft reverify owner enables same-owner `/me` recovery without rebroadcast.
- Tests: unit `notifyExternalSessionHint` silent; mounted Providers synthetic SIGNAL / STOREFRONT_CUSTOMER_KEY / ADDRESS_PERSIST_KEY no-rebroadcast + reverify.

## C1–C4 (unchanged scope)

Prior acceptance evidence remains; see T01–T12 matrix.

## Baseline F01/F02

Command: `bash harness/run-baseline-proof.sh`

- **BASE_FAIL:** F01/F02 fail on main@83949bc
- **PATCH_PASS:** patched HEAD passes — `BASELINE_PROOF=OK` in validation/baseline-proof.log.

## Gates (HEAD b647c06118d067a33290c7064f98bb528daac1b7)

See validation/*.log — lint 0 errors / 58 warnings; typecheck pass; 329 tests pass; build pass; aods PASS (openapi SKIP — no FastAPI).

## Migration

Legacy flat `karzar.addresses` without `byOwner` is discarded (non-recoverable unowned snapshot).
