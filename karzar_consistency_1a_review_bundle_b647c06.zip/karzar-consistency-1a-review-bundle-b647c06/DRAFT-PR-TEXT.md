## Consistency 1A — private account state (F01/F02)

Isolates saved addresses and private React Query caches behind a verified customer session (generation-scoped). Legacy unowned address persist is discarded on migrate.

Closes review blockers: (A) late profile mutation cannot re-establish a logged-out owner; (B) external session storage hints are receiver-only and do not rebroadcast `CUSTOMER_SESSION_SIGNAL_KEY`.

**Out of scope:** F03 cart ownership, F08 server logout proof (failed HTTP logout leaves server session unconfirmed), F06 profile PATCH policy, F07 refresh policy, payment/shipping/inventory.

**F08 wording:** Client clears private state on logout attempt; a failed or lost logout response does not prove HttpOnly session revocation on the server. No claim of authoritative server logout is made.
