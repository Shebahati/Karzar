import {
  invalidateCustomerSession,
  establishVerifiedCustomer,
  captureVerifiedCustomerSessionFence,
  isCustomerSessionFenceCurrent,
} from "@/lib/customer-session";
import {
  clearCartToken,
  getCartToken,
  setStoredToken,
  tokenStorage,
} from "@/lib/api-client";
import { clearPendingPayment } from "@/lib/pending-payment";
import { getMockApi } from "@/lib/get-mock-api";
import { env } from "@/config/env";
import { cartService } from "@/services/cart";
import { useCartStore } from "@/store/cart-store";
import type {
  MeResponse,
  OtpRequestPayload,
  OtpRequestResponse,
  OtpVerifyPayload,
  OtpVerifyResponse,
  ProfileUpdatePayload,
} from "@/types/auth";
import { apiClient } from "@/lib/api-client";

export const STOREFRONT_CUSTOMER_KEY = "karzar.storefront.customer";

interface MeBackendResponse {
  id: number;
  phone_number: string;
  full_name: string | null;
  role?: string;
  is_b2b?: boolean;
  company_name?: string | null;
}

interface StoredCustomer {
  id?: number;
  phone?: string;
  full_name?: string | null;
  company_name?: string | null;
  is_b2b?: boolean;
}

function mapMe(data: MeBackendResponse): MeResponse {
  return {
    id: data.id,
    phone: data.phone_number,
    full_name: data.full_name,
    role: data.role,
    is_b2b: data.is_b2b,
    company_name: data.company_name,
  };
}

function readStoredCustomer(): StoredCustomer | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STOREFRONT_CUSTOMER_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as StoredCustomer;
  } catch {
    return null;
  }
}

function writeStoredCustomer(customer: StoredCustomer): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STOREFRONT_CUSTOMER_KEY, JSON.stringify(customer));
  window.dispatchEvent(new Event("karzar-auth-change"));
}

/**
 * Prefer server profile fields; fill gaps from local customer cache
 * (no storefront PATCH /auth/me yet on live).
 */
function mergeLocalProfile(me: MeResponse): MeResponse {
  const local = readStoredCustomer();
  if (!local || local.id == null || local.id !== me.id) return me;
  const full_name = me.full_name?.trim() || local.full_name?.trim() || null;
  const company_name =
    me.company_name?.trim() || local.company_name?.trim() || null;
  return {
    ...me,
    full_name,
    company_name,
    is_b2b: me.is_b2b ?? local.is_b2b,
  };
}

async function syncCartAfterLogin(): Promise<string | null> {
  try {
    const guestToken = getCartToken();
    if (guestToken) {
      await cartService.merge(guestToken);
      clearCartToken();
    }
    const result = await useCartStore.getState().reconcileFromServer();
    return result.ok ? null : (result.error ?? "همگام‌سازی سبد ناموفق بود.");
  } catch {
    const message = "همگام‌سازی سبد با سرور ناموفق بود. سبد محلی حفظ شد.";
    useCartStore.getState().clearSyncError();
    useCartStore.setState({ lastSyncError: message });
    return message;
  }
}

export const authService = {
  async requestOtp(payload: OtpRequestPayload): Promise<OtpRequestResponse> {
    if (env.USE_MOCK) return (await getMockApi()).requestOtp(payload);
    // Backend OtpRequest expects `phone`, not `phone_number`.
    const { data } = await apiClient.post<OtpRequestResponse>("/auth/otp/request", {
      phone: payload.phone,
    });
    return { ...data, phone: data.phone ?? payload.phone };
  },

  async verifyOtp(payload: OtpVerifyPayload): Promise<OtpVerifyResponse> {
    const result = env.USE_MOCK
      ? await (await getMockApi()).verifyOtp(payload)
      : (
          await apiClient.post<OtpVerifyResponse>("/auth/otp/verify", {
            phone: payload.phone,
            code: payload.code,
          })
        ).data;

    const phone = result.customer.phone ?? payload.phone;
    const prev = readStoredCustomer();
    const serverName = result.customer.full_name?.trim() || null;
    const keptLocal =
      !serverName && prev?.phone === phone ? prev.full_name?.trim() || null : null;

    const normalized: OtpVerifyResponse = {
      access_token: result.access_token,
      refresh_token: result.refresh_token ?? "",
      token_type: result.token_type ?? "bearer",
      expires_in: result.expires_in ?? 1800,
      customer: {
        id: result.customer.id,
        phone,
        full_name: serverName ?? keptLocal,
      },
    };

    setStoredToken(
      normalized.access_token,
      normalized.expires_in,
      normalized.refresh_token || null,
    );

    if (typeof window !== "undefined") {
      writeStoredCustomer(normalized.customer);
      establishVerifiedCustomer(normalized.customer.id, "otp");
    }

    let cart_sync_error: string | null = null;
    if (!env.USE_MOCK) {
      cart_sync_error = await syncCartAfterLogin();
    }

    return { ...normalized, cart_sync_error };
  },

  async getMe(options?: { signal?: AbortSignal }): Promise<MeResponse> {
    if (env.USE_MOCK) return (await getMockApi()).getMe();
    const { data } = await apiClient.get<MeBackendResponse>("/auth/me", {
      signal: options?.signal,
    });
    return mergeLocalProfile(mapMe(data));
  },

  /**
   * Save profile fields on the account session.
   * OpenAPI has GET `/auth/me` only (no storefront profile PATCH) — mock updates
   * in-memory session; live keeps fields in local customer cache + me query until BE ships.
   */
  async updateProfile(payload: ProfileUpdatePayload): Promise<MeResponse> {
    const trimmed = payload.full_name.trim();
    if (trimmed.length < 2) {
      throw new Error("FULL_NAME_TOO_SHORT");
    }
    const companyRaw = payload.company_name?.trim() ?? "";
    if (companyRaw.length > 120) {
      throw new Error("COMPANY_NAME_TOO_LONG");
    }
    const company_name = companyRaw || null;

    // Fence must be captured before any await — logout/switch must block late persist.
    const fence = captureVerifiedCustomerSessionFence();

    if (env.USE_MOCK) {
      return (await getMockApi()).updateProfile({
        full_name: trimmed,
        company_name,
      });
    }

    const { data } = await apiClient.get<MeBackendResponse>("/auth/me");
    const me = mergeLocalProfile({
      ...mapMe(data),
      full_name: trimmed,
      company_name,
    });
    // Guest/checking (fence null or stale) must not re-populate STOREFRONT_CUSTOMER_KEY.
    if (
      isCustomerSessionFenceCurrent(fence) &&
      fence != null &&
      me.id === fence.ownerId
    ) {
      writeStoredCustomer({
        id: me.id,
        phone: me.phone,
        full_name: trimmed,
        company_name,
        is_b2b: me.is_b2b,
      });
    }
    return me;
  },

  async updateFullName(fullName: string): Promise<MeResponse> {
    const localCompany = readStoredCustomer()?.company_name ?? null;
    try {
      const current = await this.getMe();
      return this.updateProfile({
        full_name: fullName,
        company_name: current.company_name ?? localCompany,
      });
    } catch {
      return this.updateProfile({
        full_name: fullName,
        company_name: localCompany,
      });
    }
  },

  async logout(): Promise<void> {
    invalidateCustomerSession("guest");
    if (!env.USE_MOCK) {
      try {
        await apiClient.post("/auth/logout");
      } catch {
        // Ignore network errors on logout; still clear local session.
      }
    }
    setStoredToken(null);
    if (typeof window !== "undefined") {
      window.localStorage.removeItem(STOREFRONT_CUSTOMER_KEY);
      clearPendingPayment();
      window.dispatchEvent(new Event("karzar-auth-change"));
    }
  },

  async requestPasswordReset(phone: string): Promise<{ ok: boolean; expires_in?: number }> {
    if (env.USE_MOCK) return { ok: true, expires_in: 120 };
    const { data } = await apiClient.post<{ ok?: boolean; expires_in?: number }>(
      "/auth/password-reset/request",
      { phone },
    );
    return { ok: true, expires_in: data.expires_in };
  },

  async confirmPasswordReset(payload: {
    phone: string;
    code: string;
    new_password: string;
  }): Promise<{ ok: boolean }> {
    if (env.USE_MOCK) return { ok: true };
    const { data } = await apiClient.post<{ ok: boolean }>(
      "/auth/password-reset/confirm",
      payload,
    );
    return data;
  },

  async changePassword(payload: {
    current_password: string;
    new_password: string;
  }): Promise<{ ok: boolean }> {
    if (env.USE_MOCK) return { ok: true };
    const { data } = await apiClient.post<{ ok: boolean }>("/auth/change-password", payload);
    return data;
  },
};

export { tokenStorage };
